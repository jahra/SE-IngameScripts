﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System;
using VRage.Collections;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ObjectBuilders.Definitions;
using VRage.Game;
using VRage;
using VRageMath;

namespace IngameScript
{
    partial class Program : MyGridProgram
    {
        public Program()
        {
            Runtime.UpdateFrequency = UpdateFrequency.Update100;
        }

        public void Save()
        {
        }

        public void Main(string argument, UpdateType updateSource)
        {
           ShowIngotResources("LCDIngots");
           ShowOreResources("LCDOres");
        }
        void ShowIngotResources(String LcdName)
        {
            var lcd = GridTerminalSystem.GetBlockWithName(LcdName) as IMyTextPanel;
            List<IMyEntity> ents = new List<IMyEntity>();
            GridTerminalSystem.GetBlocksOfType<IMyEntity>(ents);
            List<MyInventoryItem> iis = new List<MyInventoryItem>();
            List<string> fs = new List<string>();
            IngotInfo[] ingots = GetIngotInfos();

            foreach (var e in ents)
            {
                for (int i = 0; i < e.InventoryCount; i++)
                {
                    e.GetInventory(i).GetItems(iis);
                }
            }

            foreach (var item in iis)
            {
                for (int i = 0; i < ingots.Length; i++)
                {
                    if (item.Type.ToString() == ingots[i].TypeName)
                        ingots[i].Amount += item.Amount.RawValue;
                }
            }

            for (int i = 0; i < ingots.Length; i++)
            {
                fs.Add(ingots[i].Text);
            }

            string s = "Ingots:\n";
            s += String.Join("\n", fs);

            lcd.WriteText(s);
        }

        void ShowOreResources(String LcdName)
        {
            var lcd = GridTerminalSystem.GetBlockWithName(LcdName) as IMyTextPanel;
            List<IMyEntity> ents = new List<IMyEntity>();
            GridTerminalSystem.GetBlocksOfType<IMyEntity>(ents);
            List<MyInventoryItem> iis = new List<MyInventoryItem>();
            List<string> fs = new List<string>();
            IngotInfo[] ingots = GetOreInfos();

            foreach (var e in ents)
            {
                for (int i = 0; i < e.InventoryCount; i++)
                {
                    e.GetInventory(i).GetItems(iis);
                }
            }

            foreach (var item in iis)
            {
                for (int i = 0; i < ingots.Length; i++)
                {
                    if (item.Type.ToString() == ingots[i].TypeName)
                        ingots[i].Amount += item.Amount.RawValue;
                }
            }

            for (int i = 0; i < ingots.Length; i++)
            {
                fs.Add(ingots[i].Text);
            }

            string s = "Ores: \n";
            s += String.Join("\n", fs);

            lcd.WriteText(s);
        }

        IngotInfo[] GetIngotInfos()
        {
            List<IngotInfo> lii = new List<IngotInfo>();
            lii.Add(new IngotInfo() { Name = "Fe", TypeName = "MyObjectBuilder_Ingot/Iron" });
            lii.Add(new IngotInfo() { Name = "Ni", TypeName = "MyObjectBuilder_Ingot/Nickel" });
            lii.Add(new IngotInfo() { Name = "Si", TypeName = "MyObjectBuilder_Ingot/Silicon" });
            lii.Add(new IngotInfo() { Name = "Co", TypeName = "MyObjectBuilder_Ingot/Cobalt" });
            lii.Add(new IngotInfo() { Name = "Ag", TypeName = "MyObjectBuilder_Ingot/Silver" });
            lii.Add(new IngotInfo() { Name = "Mg", TypeName = "MyObjectBuilder_Ingot/Magnesium" });
            lii.Add(new IngotInfo() { Name = "Au", TypeName = "MyObjectBuilder_Ingot/Gold" });
            lii.Add(new IngotInfo() { Name = "Ice", TypeName = "MyObjectBuilder_Ore/Ice" });
            return lii.ToArray();
        }

        IngotInfo[] GetOreInfos()
        {
            List<IngotInfo> lii = new List<IngotInfo>();
            lii.Add(new IngotInfo() { Name = "Fe", TypeName = "MyObjectBuilder_Ore/Iron" });
            lii.Add(new IngotInfo() { Name = "Ni", TypeName = "MyObjectBuilder_Ore/Nickel" });
            lii.Add(new IngotInfo() { Name = "Si", TypeName = "MyObjectBuilder_Ore/Silicon" });
            lii.Add(new IngotInfo() { Name = "Co", TypeName = "MyObjectBuilder_Ore/Cobalt" });
            lii.Add(new IngotInfo() { Name = "Ag", TypeName = "MyObjectBuilder_Ore/Silver" });
            lii.Add(new IngotInfo() { Name = "Mg", TypeName = "MyObjectBuilder_Ore/Magnesium" });
            lii.Add(new IngotInfo() { Name = "Au", TypeName = "MyObjectBuilder_Ore/Gold" });
            lii.Add(new IngotInfo() { Name = "Ice", TypeName = "MyObjectBuilder_Ore/Ice" });
            lii.Add(new IngotInfo() { Name = "Stone", TypeName = "MyObjectBuilder_Ore/Stone" });
            return lii.ToArray();
        }

        class IngotInfo
        {
            public string Name { get; set; }
            public string TypeName { get; set; }
            public long Amount { get; set; }

            public string Text { get { return Name + ": " + Amount / 1000000 + "kg"; } }
        }
    }
}
