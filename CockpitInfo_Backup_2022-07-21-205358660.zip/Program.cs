﻿using Sandbox.Game.EntityComponents;
using Sandbox.ModAPI.Ingame;
using Sandbox.ModAPI.Interfaces;
using SpaceEngineers.Game.ModAPI.Ingame;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System;
using VRage.Collections;
using VRage.Game.Components;
using VRage.Game.GUI.TextPanel;
using VRage.Game.ModAPI.Ingame.Utilities;
using VRage.Game.ModAPI.Ingame;
using VRage.Game.ObjectBuilders.Definitions;
using VRage.Game;
using VRage;
using VRageMath;
using Sandbox.Game.Entities.Blocks;

namespace IngameScript
{
    partial class Program : MyGridProgram
    {

        IMyCockpit c;
        

        public Program()
        {
            Runtime.UpdateFrequency = UpdateFrequency.Update10;
            List<IMyCockpit> cs = new List<IMyCockpit>();
            GridTerminalSystem.GetBlocksOfType<IMyCockpit>(cs);
            cs = cs.Where(x => x.CubeGrid == Me.CubeGrid).ToList();
            c = cs.FirstOrDefault();
        }

        public void Save()
        {
        }
        public void Main(string argument, UpdateType updateSource)
        {
            
            for (int i = 0; i < c.SurfaceCount; i++)
            {
                switch (i)
                {
                    case 0:
                        ConfigureDisplay(i);
                        c.GetSurface(i).WriteText(String.Format("{0:f}", c.GetShipSpeed()));
                        break;
                    case 1:
                        //c.GetSurface(i).WriteText("1", false);
                        break;
                    case 2:
                        //c.GetSurface(i).WriteText("2", false);
                        ConfigureDisplay(i);
                        c.GetSurface(i).WriteText(GetCargoCapacity());
                        break;
                    case 3:
                        //c.GetSurface(i).WriteText("3", false);
                        break;
                    
                    default:
                        break;
                }

            }
        }

        public string GetInventoryItems()
        {
            List<IMyTerminalBlock> ents = new List<IMyTerminalBlock>();
            GridTerminalSystem.GetBlocksOfType<IMyEntity>(ents);
            ents = ents.Where(x => x.HasInventory && x.GetInventory().ItemCount > 0).ToList();
            foreach (var item in ents)
            {
                
            }

            return null;
        }

        public void ConfigureDisplay(int i)
        {
            c.GetSurface(i).Alignment = TextAlignment.CENTER;
            c.GetSurface(i).FontSize = 3;
            c.GetSurface(i).ContentType = ContentType.TEXT_AND_IMAGE;
        }

        public string GetCargoCapacity()
        {
            List<IMyTerminalBlock> blocks = new List<IMyTerminalBlock>();
            List<IMyTerminalBlock> inventory = new List<IMyTerminalBlock>();
            GridTerminalSystem.GetBlocksOfType<IMyCargoContainer>(blocks);
            inventory.AddList(blocks);
            GridTerminalSystem.GetBlocksOfType<IMyShipDrill>(blocks);
            inventory.AddList(blocks);
            GridTerminalSystem.GetBlocksOfType<IMyShipConnector>(blocks);
            IMyShipConnector conn = (IMyShipConnector)blocks.Where(x => x.CubeGrid == Me.CubeGrid).FirstOrDefault();
            if (conn == null)
                return "No connector found";
            inventory.AddList(blocks);

            inventory = inventory.Where(x => x.HasInventory && Me.CubeGrid == x.CubeGrid && x.GetInventory().IsConnectedTo(conn.GetInventory())).ToList();
            
            double current = 0;
            double max = 0;
            foreach (var i in inventory)
            {
                current += (double)i.GetInventory().CurrentVolume;
                max += (double)i.GetInventory().MaxVolume;
            }
            Echo(String.Format("Total cargo capacity: {0:f}/{1:f}  {2:f}%", current, max, (current / max) * 100));
            return String.Format("{0:f}%", (current/max)*100);
        }
        ComponentInfo[] GetComponentInfos()
        {
            List<ComponentInfo> lci = new List<ComponentInfo>();
            lci.Add(new ComponentInfo() { Name = "Steel:          ", TypeName = "MyObjectBuilder_Component/SteelPlate", Desired = 4000, BlueprintName = "MyObjectBuilder_BlueprintDefinition/SteelPlate" });
            lci.Add(new ComponentInfo() { Name = "Glass:          ", TypeName = "MyObjectBuilder_Component/BulletproofGlass", Desired = 100, BlueprintName = "MyObjectBuilder_BlueprintDefinition/BulletproofGlass" });
            lci.Add(new ComponentInfo() { Name = "Detector:       ", TypeName = "MyObjectBuilder_Component/Detector", Desired = 10, BlueprintName = "MyObjectBuilder_BlueprintDefinition/DetectorComponent" });
            lci.Add(new ComponentInfo() { Name = "Girder:         ", TypeName = "MyObjectBuilder_Component/Girder", Desired = 100, BlueprintName = "MyObjectBuilder_BlueprintDefinition/GirderComponent" });
            lci.Add(new ComponentInfo() { Name = "Display:        ", TypeName = "MyObjectBuilder_Component/Display", Desired = 1000, BlueprintName = "MyObjectBuilder_BlueprintDefinition/Display" });
            lci.Add(new ComponentInfo() { Name = "LargeTube:      ", TypeName = "MyObjectBuilder_Component/LargeTube", Desired = 1000, BlueprintName = "MyObjectBuilder_BlueprintDefinition/LargeTube" });
            lci.Add(new ComponentInfo() { Name = "GravityG:       ", TypeName = "MyObjectBuilder_Component/GravityGenerator", Desired = 1, BlueprintName = "MyObjectBuilder_BlueprintDefinition/GravityGeneratorComponent" });
            lci.Add(new ComponentInfo() { Name = "MetalGrid:      ", TypeName = "MyObjectBuilder_Component/MetalGrid", Desired = 100, BlueprintName = "MyObjectBuilder_BlueprintDefinition/MetalGrid" });
            lci.Add(new ComponentInfo() { Name = "Motor:          ", TypeName = "MyObjectBuilder_Component/Motor", Desired = 1000, BlueprintName = "MyObjectBuilder_BlueprintDefinition/MotorComponent" });
            lci.Add(new ComponentInfo() { Name = "PowerCell:      ", TypeName = "MyObjectBuilder_Component/PowerCell", Desired = 100, BlueprintName = "MyObjectBuilder_BlueprintDefinition/PowerCell" });
            lci.Add(new ComponentInfo() { Name = "RadioComm:      ", TypeName = "MyObjectBuilder_Component/RadioCommunication", Desired = 1, BlueprintName = "MyObjectBuilder_BlueprintDefinition/RadioCommunicationComponent" });
            lci.Add(new ComponentInfo() { Name = "Reactor:        ", TypeName = "MyObjectBuilder_Component/Reactor", Desired = 1, BlueprintName = "MyObjectBuilder_BlueprintDefinition/ReactorComponent" });
            lci.Add(new ComponentInfo() { Name = "SmallTube:      ", TypeName = "MyObjectBuilder_Component/SmallTube", Desired = 1000, BlueprintName = "MyObjectBuilder_BlueprintDefinition/SmallTube" });
            lci.Add(new ComponentInfo() { Name = "Supercond:      ", TypeName = "MyObjectBuilder_Component/Superconductor", Desired = 100, BlueprintName = "MyObjectBuilder_BlueprintDefinition/Superconductor" });
            lci.Add(new ComponentInfo() { Name = "SolarCell:      ", TypeName = "MyObjectBuilder_Component/SolarCell", Desired = 1, BlueprintName = "MyObjectBuilder_BlueprintDefinition/SolarCell" });
            lci.Add(new ComponentInfo() { Name = "InterPlate:     ", TypeName = "MyObjectBuilder_Component/InteriorPlate", Desired = 1000, BlueprintName = "MyObjectBuilder_BlueprintDefinition/InteriorPlate" });
            lci.Add(new ComponentInfo() { Name = "Computer:       ", TypeName = "MyObjectBuilder_Component/Computer", Desired = 1000, BlueprintName = "MyObjectBuilder_BlueprintDefinition/ComputerComponent" });
            lci.Add(new ComponentInfo() { Name = "ConstComp:      ", TypeName = "MyObjectBuilder_Component/Construction", Desired = 2000, BlueprintName = "MyObjectBuilder_BlueprintDefinition/ConstructionComponent" });
            lci.Add(new ComponentInfo() { Name = "Ammo:           ", TypeName = "MyObjectBuilder_AmmoMagazine/NATO_25x184mm", Desired = 300, BlueprintName = "MyObjectBuilder_BlueprintDefinition/NATO_25x184mmMagazine" });
            lci.Add(new ComponentInfo() { Name = "Thruster comp:  ", TypeName = "MyObjectBuilder_Component/Thrust", Desired = 100, BlueprintName = "MyObjectBuilder_BlueprintDefinition/ThrustComponent" });
            return lci.ToArray();
        }

        class ComponentInfo
        {
            public string Name { get; set; }
            public string TypeName { get; set; }
            public string BlueprintName { get; set; }
            public long Amount { get; set; }
            public long Desired { get; set; }
            public double Needed { get { return Desired - Amount / 1000000; } }

            public string Text { get { return Name + Amount / 1000000 + "/" + Desired; } }
        }
    }
}
